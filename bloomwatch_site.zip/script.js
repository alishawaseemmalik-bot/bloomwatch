// Leaflet map
var map = L.map('mapid').setView([33.6844, 73.0479], 5);
L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    attribution: '&copy; OpenStreetMap contributors'
}).addTo(map);
L.marker([33.6844, 73.0479]).addTo(map).bindPopup('Sample Bloom Location');

// Chart.js chart
const ctx = document.getElementById('bloomChart').getContext('2d');
new Chart(ctx, {
    type: 'line',
    data: {
        labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
        datasets: [{
            label: 'Bloom Intensity',
            data: [3, 5, 8, 12, 7, 4],
            borderColor: 'rgba(233, 30, 99, 1)',
            backgroundColor: 'rgba(233, 30, 99, 0.2)',
            fill: true,
            tension: 0.4
        }]
    },
    options: {
        responsive: true,
        plugins: {
            legend: {
                position: 'top',
            },
            title: {
                display: true,
                text: 'Flower Blooming Over Months'
            }
        }
    }
});
